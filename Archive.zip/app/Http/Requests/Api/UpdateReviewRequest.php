<?php

namespace App\Http\Requests\Api;

use App\Models\Product;
use App\Models\Review;
use Illuminate\Foundation\Http\FormRequest;

class UpdateReviewRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        $product = $this->route('product');
        $review = $this->route('review');

        if (! $product instanceof Product || ! $review instanceof Review) {
            return false;
        }

        return $this->user()?->id === $review->user_id
            && $review->product_id === $product->id;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'rating' => 'sometimes|integer|min:1|max:5',
            'comment' => 'sometimes|nullable|string|max:2000',
            'images' => 'sometimes|array|max:6',
            'images.*' => 'required|image|max:5120',
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'images.array' => 'Images must be sent as an array.',
            'images.max' => 'You can upload up to 6 images.',
            'images.*.image' => 'Each file must be an image.',
            'images.*.max' => 'Each image must not exceed 5 MB.',
        ];
    }
}
