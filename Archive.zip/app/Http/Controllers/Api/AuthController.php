<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Models\User;
use Illuminate\Database\QueryException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules\Password;

class AuthController extends Controller
{
    public function requestRegistrationOtp(Request $request): JsonResponse
    {
        $request->request->remove('otp');
        $request->request->remove('sms_otp');

        return $this->register($request);
    }

    public function completeRegistration(Request $request): JsonResponse
    {
        $otpValidator = Validator::make($request->all(), [
            'otp' => 'required_without:sms_otp|digits:6',
            'sms_otp' => 'required_without:otp|digits:6',
        ]);

        if ($otpValidator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'SMS OTP is required for verification.',
                'errors' => $otpValidator->errors(),
            ], 422);
        }

        return $this->register($request);
    }

    public function register(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'nullable|email|max:150|unique:users,email',
            'phone' => 'required|string|max:20|unique:users,phone',
            'password' => ['required', 'confirmed', Password::min(6)],
            'otp' => 'nullable|digits:6',
            'sms_otp' => 'nullable|digits:6',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $validated = $validator->validated();

        $otpCacheKey = $this->otpCacheKey($validated['phone']);
        $smsOtpInput = (string) ($validated['sms_otp'] ?? $validated['otp'] ?? '');

        if (blank($smsOtpInput)) {
            $smsOtp = (string) random_int(100000, 999999);

            Cache::put($otpCacheKey, [
                'sms_otp_hash' => Hash::make($smsOtp),
            ], now()->addMinutes(10));

            try {
                $smsDelivery = $this->sendRegistrationOtpSms($validated['phone'], $smsOtp);
            } catch (\Throwable $exception) {
                $smsDelivery = [
                    'channel' => 'sms',
                    'sent' => false,
                    'reason' => app()->hasDebugModeEnabled()
                        ? $exception->getMessage()
                        : 'SMS delivery failed.',
                ];
            }

            if (! $smsDelivery['sent'] && $this->canBypassOtpDelivery()) {
                return response()->json([
                    'status' => true,
                    'message' => 'OTP generated in debug bypass mode. Complete provider setup for real delivery.',
                    'data' => [
                        'otp_required' => true,
                        'sms_otp_required' => true,
                        'otp_expires_in_seconds' => 600,
                        'otp_preview' => [
                            'sms_otp' => $smsOtp,
                        ],
                        'bypass_mode' => true,
                        'delivery' => [
                            'sms' => $this->formatDeliveryStatus($smsDelivery),
                        ],
                        'delivery_note' => 'sent=true means request submitted to provider. Final handset delivery must be verified in provider logs.',
                    ],
                ]);
            }

            if (! $smsDelivery['sent']) {
                Cache::forget($otpCacheKey);

                $responseData = [
                    'otp_required' => true,
                    'sms_otp_required' => true,
                    'otp_expires_in_seconds' => 600,
                    'delivery' => [
                        'sms' => $this->formatDeliveryStatus($smsDelivery),
                    ],
                    'delivery_note' => 'sent=true means request submitted to provider. Final handset delivery must be verified in provider logs.',
                ];

                if ($this->canBypassOtpDelivery()) {
                    $responseData['otp_preview'] = [
                        'sms_otp' => $smsOtp,
                    ];
                }

                return response()->json([
                    'status' => false,
                    'message' => 'OTP could not be delivered via SMS. Please check configuration.',
                    'data' => $responseData,
                ], 422);
            }

            $responseData = [
                'otp_required' => true,
                'sms_otp_required' => true,
                'otp_expires_in_seconds' => 600,
                'delivery' => [
                    'sms' => $this->formatDeliveryStatus($smsDelivery),
                ],
                'delivery_note' => 'sent=true means request submitted to provider. Final handset delivery must be verified in provider logs.',
            ];

            if ($this->canBypassOtpDelivery()) {
                $responseData['otp_preview'] = [
                    'sms_otp' => $smsOtp,
                ];
            }

            return response()->json([
                'status' => true,
                'message' => 'OTP sent successfully to mobile number.',
                'data' => $responseData,
            ]);
        }

        $cachedOtpData = Cache::get($otpCacheKey);

        if (
            ! is_array($cachedOtpData)
            || blank($cachedOtpData['sms_otp_hash'] ?? null)
        ) {
            return response()->json([
                'status' => false,
                'message' => 'OTP expired or not found. Please request a new OTP.',
            ], 422);
        }

        if (blank($smsOtpInput)) {
            return response()->json([
                'status' => false,
                'message' => 'SMS OTP is required for verification.',
            ], 422);
        }

        if (
            ! Hash::check($smsOtpInput, (string) ($cachedOtpData['sms_otp_hash'] ?? ''))
        ) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid OTP',
            ], 422);
        }

        Cache::forget($otpCacheKey);
 
        try {
            $registrationEmail = filled($validated['email'] ?? null)
                ? strtolower(trim((string) $validated['email']))
                : $this->buildFallbackRegistrationEmail($validated['phone']);

            $user = User::create([
                'name' => $validated['name'],
                'email' => $registrationEmail,
                'phone' => $validated['phone'],
                'password' => Hash::make($validated['password']),
                'role' => 'customer',
                'status' => 'active',
            ]);

            $token = $user->createToken('api')->plainTextToken;
        } catch (QueryException $exception) {
            return response()->json([
                'status' => false,
                'message' => 'Registration failed. Please try again later.',
                'debug_message' => app()->hasDebugModeEnabled() ? $exception->getMessage() : null,
            ], 503);
        }

        return response()->json([
            'status' => true,
            'message' => 'Registration successful',
            'data' => [
                'user' => $user,
                'token' => $token,
                'token_type' => 'Bearer',
            ],
        ], 201);
    }

    private function otpCacheKey(string $phone): string
    {
        return 'register_otp:'.sha1(trim($phone));
    }

    private function buildFallbackRegistrationEmail(string $phone): string
    {
        $normalizedPhone = preg_replace('/\D+/', '', $phone);

        if (blank($normalizedPhone)) {
            $normalizedPhone = Str::lower((string) Str::ulid());
        }

        return 'phone_'.$normalizedPhone.'@genzwearables.local';
    }



    /**
     * @return array{channel:string,sent:bool,reason:?string}
     */
    private function sendRegistrationOtpSms(string $phone, string $otp): array
    {
        $authkeyApiKey = (string) Setting::get('authkey_api_key', '');
        $authkeySenderId = trim((string) Setting::get('authkey_sender_id', ''));
        $authkeyTemplateId = trim((string) Setting::get('authkey_template_id', ''));

        if (blank($authkeyApiKey)) {
            return [
                'channel' => 'sms',
                'sent' => false,
                'reason' => 'Authkey API key is missing in settings.',
            ];
        }

        $normalizedPhone = preg_replace('/\D+/', '', $phone);

        if (blank($normalizedPhone)) {
            return [
                'channel' => 'sms',
                'sent' => false,
                'reason' => 'Phone number is invalid.',
            ];
        }

        $mobileCandidates = collect([
            $normalizedPhone,
            '91'.$normalizedPhone,
            '+91'.$normalizedPhone,
        ])->unique()->values();

        $failureReasons = [];

        foreach ($mobileCandidates as $mobileCandidate) {
            $requestVariants = [
                [
                    'authkey' => $authkeyApiKey,
                    'mobile' => $mobileCandidate,
                    'country_code' => 91,
                    'otp' => $otp,
                ],
                [
                    'authkey' => $authkeyApiKey,
                    'mobile' => $mobileCandidate,
                    'country_code' => 91,
                ],
            ];

            if (filled($authkeySenderId)) {
                $requestVariants[0]['sid'] = $authkeySenderId;
                $requestVariants[1]['sid'] = $authkeySenderId;
            }

            if (filled($authkeyTemplateId)) {
                $requestVariants[0]['template_id'] = $authkeyTemplateId;
                $requestVariants[1]['template_id'] = $authkeyTemplateId;
            }

            foreach ($requestVariants as $variantIndex => $queryParams) {
                $response = Http::connectTimeout(3)
                    ->timeout(5)
                    ->acceptJson()
                    ->get('https://api.authkey.io/request', $queryParams);

                $delivery = $this->parseAuthkeyResponse($response);

                if ($delivery['sent']) {
                    return [
                        'channel' => 'sms',
                        'sent' => true,
                        'reason' => null,
                    ];
                }

                if (filled($delivery['reason'])) {
                    $attempt = $variantIndex === 0 ? 'with-otp' : 'without-otp';
                    $failureReasons[] = 'mobile '.$mobileCandidate.' ('.$attempt.'): '.$delivery['reason'];
                }
            }
        }

        return [
            'channel' => 'sms',
            'sent' => false,
            'reason' => filled($failureReasons)
                ? Str::limit(implode(' | ', array_unique($failureReasons)), 450)
                : 'Authkey response could not be verified as successful.',
        ];
    }

    /**
     * @return array{sent:bool,reason:?string}
     */
    private function parseAuthkeyResponse($response): array
    {
        if (! $response->successful()) {
            return [
                'sent' => false,
                'reason' => 'HTTP '.$response->status().': '.Str::limit(trim($response->body()), 180),
            ];
        }

        $payload = $response->json();

        if (is_array($payload)) {
            $statusValue = data_get($payload, 'status', data_get($payload, 'Status', data_get($payload, 'success', data_get($payload, 'Success'))));
            $statusCodeValue = data_get($payload, 'code', data_get($payload, 'Code', data_get($payload, 'statusCode', data_get($payload, 'status_code', data_get($payload, 'StatusCode')))));
            $message = (string) (data_get($payload, 'message')
                ?: data_get($payload, 'Message')
                ?: data_get($payload, 'error')
                ?: data_get($payload, 'Error')
                ?: data_get($payload, 'description')
                ?: data_get($payload, 'Description')
                ?: '');

            $normalizedStatus = strtolower(trim((string) $statusValue));
            $normalizedMessage = strtolower(trim($message));

            if (in_array($normalizedStatus, ['success', 'ok', 'sent', 'true', '1'], true)) {
                return ['sent' => true, 'reason' => null];
            }

            if (in_array((string) $statusCodeValue, ['200', '201'], true)) {
                return ['sent' => true, 'reason' => null];
            }

            if (
                str_contains($normalizedMessage, 'otp sent')
                || str_contains($normalizedMessage, 'sent successfully')
                || str_contains($normalizedMessage, 'submitted successfully')
            ) {
                return ['sent' => true, 'reason' => null];
            }

            if (str_contains($normalizedMessage, 'nothing to do')) {
                return [
                    'sent' => false,
                    'reason' => 'Authkey responded "Nothing to do". Usually sender/template/route parameters are missing or OTP request is blocked for current config.',
                ];
            }

            if (filled(data_get($payload, 'id')) || filled(data_get($payload, 'request_id')) || filled(data_get($payload, 'message_id'))) {
                return ['sent' => true, 'reason' => null];
            }

            return [
                'sent' => false,
                'reason' => filled($message)
                    ? $message
                    : 'Unverified JSON response: '.Str::limit(json_encode($payload), 180),
            ];
        }

        $responseBody = strtolower(trim($response->body()));

        if (str_contains($responseBody, 'success') || str_contains($responseBody, 'sent') || str_contains($responseBody, 'otp')) {
            return ['sent' => true, 'reason' => null];
        }

        return [
            'sent' => false,
            'reason' => 'Unverified response body: '.Str::limit(trim($response->body()), 180),
        ];
    }

    private function canBypassOtpDelivery(): bool
    {
        return (bool) config('app.debug');
    }

    /**
     * @param  array{channel:string,sent:bool,reason:?string}  $delivery
     * @return array{channel:string,sent:bool,submitted_to_provider:bool,delivered_to_inbox:string,reason:?string}
     */
    private function formatDeliveryStatus(array $delivery): array
    {
        $reason = $delivery['reason'] ?? null;

        if (($delivery['sent'] ?? false) && blank($reason)) {
            $reason = 'Submitted to provider. Final delivery is provider-dependent.';
        }

        return [
            'channel' => (string) ($delivery['channel'] ?? ''),
            'sent' => (bool) ($delivery['sent'] ?? false),
            'submitted_to_provider' => (bool) ($delivery['sent'] ?? false),
            'delivered_to_inbox' => 'unknown',
            'reason' => $reason,
        ];
    }

    public function login(Request $request)
    {
        $validated = $request->validate([
            'phone' => 'required|string',
            'password' => 'required|string',
        ]);

        $user = User::where('phone', $validated['phone'])->first();

        if (! $user || ! Hash::check($validated['password'], $user->password)) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid credentials',
            ], 401);
        }

        $token = $user->createToken('api')->plainTextToken;

        return response()->json([
            'status' => true,
            'message' => 'Login successful',
            'data' => [
                'user' => $user,
                'token' => $token,
                'token_type' => 'Bearer',
            ],
        ]);
    }

    public function me(Request $request)
    {
        $user = $request->user()?->load('addresses');

        return response()->json([
            'status' => true,
            'data' => [
                'user' => $user,
            ],
        ]);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()?->delete();

        return response()->json([
            'status' => true,
            'message' => 'Logged out successfully',
        ]);
    }

    public function forgotPassword(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'phone' => 'required|string|max:20',
        ]);

        $user = User::where('phone', $validated['phone'])->first();

        if (! $user) {
            return response()->json([
                'status' => false,
                'message' => 'User not found with this phone number.',
            ], 404);
        }

        $otpCacheKey = $this->forgotPasswordOtpCacheKey($validated['phone']);
        $resetOtp = (string) random_int(100000, 999999);

        Cache::put($otpCacheKey, [
            'otp_hash' => Hash::make($resetOtp),
        ], now()->addMinutes(10));

        try {
            $smsDelivery = $this->sendForgotPasswordOtpSms($validated['phone'], $resetOtp);
        } catch (\Throwable $exception) {
            $smsDelivery = [
                'channel' => 'sms',
                'sent' => false,
                'reason' => app()->hasDebugModeEnabled()
                    ? $exception->getMessage()
                    : 'SMS delivery failed.',
            ];
        }

        if (! $smsDelivery['sent'] && $this->canBypassOtpDelivery()) {
            return response()->json([
                'status' => true,
                'message' => 'OTP generated in debug bypass mode.',
                'data' => [
                    'otp_required' => true,
                    'otp_expires_in_seconds' => 600,
                    'otp_preview' => [
                        'otp' => $resetOtp,
                    ],
                    'bypass_mode' => true,
                ],
            ]);
        }

        if (! $smsDelivery['sent']) {
            Cache::forget($otpCacheKey);

            return response()->json([
                'status' => false,
                'message' => 'OTP could not be delivered via SMS. Please check configuration.',
                'data' => [
                    'otp_required' => true,
                    'otp_expires_in_seconds' => 600,
                    'otp_preview' => [
                        'otp' => $resetOtp,
                    ],
                ],
            ], 422);
        }

        return response()->json([
            'status' => true,
            'message' => 'OTP sent successfully to your mobile number.',
            'data' => [
                'otp_required' => true,
                'otp_expires_in_seconds' => 600,
                'otp_preview' => [
                    'otp' => $resetOtp,
                ],
            ],
        ]);
    }

    public function resetPassword(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'phone' => 'required|string|max:20',
            'otp' => 'required|digits:6',
            'password' => ['required', 'confirmed', Password::min(6)],
        ]);

        $user = User::where('phone', $validated['phone'])->first();

        if (! $user) {
            return response()->json([
                'status' => false,
                'message' => 'User not found with this phone number.',
            ], 404);
        }

        $otpCacheKey = $this->forgotPasswordOtpCacheKey($validated['phone']);
        $cachedOtpData = Cache::get($otpCacheKey);

        if (! is_array($cachedOtpData) || blank($cachedOtpData['otp_hash'] ?? null)) {
            return response()->json([
                'status' => false,
                'message' => 'OTP expired or not found. Please request a new OTP.',
            ], 422);
        }

        if (! Hash::check($validated['otp'], (string) ($cachedOtpData['otp_hash'] ?? ''))) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid OTP.',
            ], 422);
        }

        Cache::forget($otpCacheKey);

        $user->update([
            'password' => Hash::make($validated['password']),
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Password reset successfully. You can now login with your new password.',
        ]);
    }

    private function forgotPasswordOtpCacheKey(string $phone): string
    {
        return 'forgot_password_otp:'.sha1(trim($phone));
    }

    /**
     * @return array{channel:string,sent:bool,reason:?string}
     */
    private function sendForgotPasswordOtpSms(string $phone, string $otp): array
    {
        $authkeyApiKey = (string) Setting::get('authkey_api_key', '');
        $authkeySenderId = trim((string) Setting::get('authkey_sender_id', ''));
        $authkeyTemplateId = trim((string) Setting::get('authkey_template_id', ''));

        if (blank($authkeyApiKey)) {
            return [
                'channel' => 'sms',
                'sent' => false,
                'reason' => 'Authkey API key is missing in settings.',
            ];
        }

        $normalizedPhone = preg_replace('/\D+/', '', $phone);

        if (blank($normalizedPhone)) {
            return [
                'channel' => 'sms',
                'sent' => false,
                'reason' => 'Phone number is invalid.',
            ];
        }

        $mobileCandidates = collect([
            $normalizedPhone,
            '91'.$normalizedPhone,
            '+91'.$normalizedPhone,
        ])->unique()->values();

        $failureReasons = [];

        foreach ($mobileCandidates as $mobileCandidate) {
            $requestVariants = [
                [
                    'authkey' => $authkeyApiKey,
                    'mobile' => $mobileCandidate,
                    'country_code' => 91,
                    'otp' => $otp,
                ],
                [
                    'authkey' => $authkeyApiKey,
                    'mobile' => $mobileCandidate,
                    'country_code' => 91,
                ],
            ];

            if (filled($authkeySenderId)) {
                $requestVariants[0]['sid'] = $authkeySenderId;
                $requestVariants[1]['sid'] = $authkeySenderId;
            }

            if (filled($authkeyTemplateId)) {
                $requestVariants[0]['template_id'] = $authkeyTemplateId;
                $requestVariants[1]['template_id'] = $authkeyTemplateId;
            }

            foreach ($requestVariants as $variantIndex => $queryParams) {
                $response = Http::connectTimeout(3)
                    ->timeout(5)
                    ->acceptJson()
                    ->get('https://api.authkey.io/request', $queryParams);

                $delivery = $this->parseAuthkeyResponse($response);

                if ($delivery['sent']) {
                    return [
                        'channel' => 'sms',
                        'sent' => true,
                        'reason' => null,
                    ];
                }

                if (filled($delivery['reason'])) {
                    $attempt = $variantIndex === 0 ? 'with-otp' : 'without-otp';
                    $failureReasons[] = 'mobile '.$mobileCandidate.' ('.$attempt.'): '.$delivery['reason'];
                }
            }
        }

        return [
            'channel' => 'sms',
            'sent' => false,
            'reason' => filled($failureReasons)
                ? Str::limit(implode(' | ', array_unique($failureReasons)), 450)
                : 'Authkey response could not be verified as successful.',
        ];
    }
}
